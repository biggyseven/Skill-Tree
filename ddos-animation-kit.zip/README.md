# Kit d'intégration — Simulation DDoS interactive

Ce kit ajoute à un cours Markdown une simulation inspirée de la capture : flux animés, curseur « Attack traffic », file d'attente, capacité, débit servi, pause et réinitialisation.

## Fichiers

- `ddos-mitigation-debutant.md` : cours avec schéma animé de secours et un emplacement `data-lesson-widget="ddos-overload-v1"`.
- `ddos-simulator.html` : modèle HTML du composant à inclure dans le layout frontend de confiance.
- `ddos-simulator.css` : styles du composant.
- `ddos-simulator.js` : logique Alpine et fonction de montage.

## Intégration générale

1. Charge `ddos-simulator.css` depuis la feuille CSS globale de ton frontend.
2. Inclus le contenu de `ddos-simulator.html` dans le layout de base Jinja2/FastAPI, hors de la zone de contenu Markdown, afin que le `<template id="ddos-overload-template">` ne passe pas par DOMPurify.
3. Charge `ddos-simulator.js` dans le frontend avant de monter les widgets (si tu utilises un bundle, importe ce fichier depuis le point d'entrée qui initialise Alpine).
4. Dans le rendu du cours, conserve l'ordre `Marked.parse(markdown)`, puis `DOMPurify.sanitize(html)`, puis injecte le HTML nettoyé dans le conteneur.
5. Après l'injection du HTML nettoyé, appelle `window.mountDdosMitigationWidgets(containerDuCours)`.

Exemple simplifié :

```js
const html = marked.parse(markdownText);
const cleanHtml = DOMPurify.sanitize(html);
lessonContainer.innerHTML = cleanHtml;
window.mountDdosMitigationWidgets(lessonContainer);
```

Le remplacement intervient **après** DOMPurify uniquement pour le marqueur reconnu et avec un template statique inclus par le frontend. Ne construis jamais le template à partir de contenu fourni dans un cours. Cela évite de compter sur la conservation d'attributs Alpine (`x-data`, `x-text`, `@click`) que DOMPurify peut filtrer.

## Chargement Alpine

Le composant suppose qu'Alpine.js est chargé par le frontend. Le fichier JavaScript enregistre `ddosSimulator` sur l'événement `alpine:init` si nécessaire, puis appelle `Alpine.initTree(widget)` quand le marqueur a été remplacé. Si ton application monte les cours de façon asynchrone, appelle `mountDdosMitigationWidgets` après chaque rendu.

## Comment fonctionne le modèle

- Valeur initiale : attaque 35 requêtes/s, trafic légitime 40 requêtes/s, capacité 120 requêtes/s.
- Si l'arrivée dépasse la capacité, la file grandit ; si elle atteint 80 requêtes, le modèle affiche un débit excédentaire susceptible d'être rejeté.
- Si le trafic repasse sous la capacité, la file se résorbe.
- Le bouton Pause suspend la progression de la file et l'animation CSS ; Réinitialiser remet le scénario initial.

Ce modèle est volontairement pédagogique, pas un simulateur de réseau complet. Les chiffres ne proviennent pas d'un équipement réel.

## Sécurité et compatibilité

Le Markdown ne contient aucune balise `<script>` ni attribut d'événement. L'interactivité réside dans le frontend de confiance. Le schéma de secours utilise HTML/SVG simple et des animations CSS. La configuration réelle de DOMPurify, la politique CSP et le moment du montage doivent être testés dans le lecteur. La préférence `prefers-reduced-motion` désactive le mouvement CSS pour les utilisateurs qui ont demandé une réduction des animations.
