/*
 * Composant Alpine.js de confiance : ne pas insérer ce code dans le Markdown.
 * Charger ce fichier dans le frontend, idéalement avant Alpine.start().
 */
(function () {
  function component() {
    return {
      attack: 35,
      legitimate: 40,
      capacity: 120,
      queueLimit: 80,
      queue: 0,
      paused: false,
      _timer: null,
      _last: null,

      start() {
        if (this._timer) window.clearInterval(this._timer);
        this._last = Date.now();
        this._timer = window.setInterval(() => this.tick(), 250);
      },

      destroy() {
        if (this._timer) window.clearInterval(this._timer);
        this._timer = null;
      },

      tick() {
        const now = Date.now();
        const elapsed = Math.min(1, Math.max(0, (now - (this._last || now)) / 1000));
        this._last = now;
        if (this.paused) return;
        const difference = this.arrivalRate - this.capacity;
        if (difference > 0) {
          this.queue = Math.min(this.queueLimit, this.queue + difference * elapsed);
        } else {
          this.queue = Math.max(0, this.queue + difference * elapsed);
        }
      },

      resetSimulation() {
        this.attack = 35;
        this.queue = 0;
        this.paused = false;
        this._last = Date.now();
      },

      get arrivalRate() {
        return this.attack + this.legitimate;
      },

      get servedRate() {
        return this.queue > 0.5 ? this.capacity : Math.min(this.arrivalRate, this.capacity);
      },

      get queuePercent() {
        return this.queueLimit > 0 ? Math.min(100, (this.queue / this.queueLimit) * 100) : 0;
      },

      get queueFull() {
        return this.queue >= this.queueLimit - 0.05;
      },

      get overloaded() {
        return this.arrivalRate > this.capacity;
      },

      get droppedRate() {
        return this.queueFull && this.overloaded ? this.arrivalRate - this.capacity : 0;
      },

      get waitLabel() {
        if (this.queue <= 0.5) return '0';
        return (this.queue / this.capacity).toFixed(1);
      },

      get statusText() {
        if (!this.overloaded && this.queue <= 0.5) {
          return `${this.arrivalRate} /s arrive within ${this.capacity} /s capacity, so no backlog grows.`;
        }
        if (this.overloaded && !this.queueFull) {
          return `${this.arrivalRate} /s arrive for ${this.capacity} /s capacity. The queue is growing by ${this.arrivalRate - this.capacity} requests/s.`;
        }
        if (this.queueFull && this.overloaded) {
          return `Queue full: ${this.arrivalRate - this.capacity} requests/s exceed the service capacity and may be dropped.`;
        }
        return `Traffic is back below capacity. The queue is draining toward zero.`;
      }
    };
  }

  // Register the component whether this file loads before or after Alpine is present.
  function register() {
    if (window.Alpine && !window.__ddosSimulatorRegistered) {
      window.Alpine.data('ddosSimulator', component);
      window.__ddosSimulatorRegistered = true;
    }
  }

  if (window.Alpine) register();
  document.addEventListener('alpine:init', register, { once: true });

  // Call after Marked.parse() AND DOMPurify.sanitize() have populated the lesson container.
  window.mountDdosMitigationWidgets = function (root) {
    const scope = root || document;
    if (!window.Alpine) return;
    const placeholder = scope.querySelector('[data-lesson-widget="ddos-overload-v1"]');
    const template = document.getElementById('ddos-overload-template');
    if (!placeholder || !template || placeholder.dataset.widgetMounted === 'true') return;

    const widget = template.content.firstElementChild.cloneNode(true);
    placeholder.replaceWith(widget);
    window.Alpine.initTree(widget);
  };
})();
